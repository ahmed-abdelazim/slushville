<?php
$errors = [];
$data = [];

if (!empty($errors)) {
    $data['success'] = false;
    $data['errors'] = $errors;
} else {
    $data['success'] = true;
    if( $data['success'] == true ){
		$name = $_REQUEST['name'];
		$email = $_REQUEST['email'];
		
		$semail ="chauhanveer53@gmail.com";
        $to = $semail;
        $froms = 'info@codeset.online';
        $fromsName = 'Slushville';
        $subject ="Website Contact Information";
        $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".$fromsName." <".$froms.">\r\n";			
            $email_body = '<html><head>
                   <title> Contact Information </title>
                   </head>
                   <body>';
        $email_body .= '<p style="font-size:16px;color:#000;">Name : <b>'.$name.'</b></p>';
		$email_body .= '<p style="font-size:16px;color:#000;">Email : <b>'.$email.'</b></p>';
		$email_body .= "</body></html>"; 
		mail($to,$subject,$email_body,$headers);
		
		/*Auto Responder*/
        $to_1 = $email;
        $from = 'info@codeset.online'; 
       $fromName = 'Slushville'; 
        $subject_1 ="Thank You for Contact with us";
       $message ="Attachment File";
        $file ="Attachment.pdf";
      
$content = file_get_contents( $file);
$content = chunk_split(base64_encode($content));
$uid = md5(uniqid(time()));
$file_name = basename($file);

// header
$header1 = "From: ".$fromName." <".$from.">\r\n";
$header1 .= "Reply-To: ".$replyto."\r\n";
$header1 .= "MIME-Version: 1.0\r\n";
$header1 .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";

// message & attachment
$nmessage = "--".$uid."\r\n";
$nmessage .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$nmessage .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
$nmessage .= $message."\r\n\r\n";
$nmessage .= "--".$uid."\r\n";
$nmessage .= "Content-Type: application/octet-stream; name=\"".$filename."\"\r\n";
$nmessage .= "Content-Transfer-Encoding: base64\r\n";
$nmessage .= "Content-Disposition: attachment; filename=\"".$file_name."\"\r\n\r\n";
$nmessage .= $content."\r\n\r\n";
$nmessage .= "--".$uid."--";
         mail($to_1,$subject_1,$nmessage,$header1);
        
        $data['message'] = 'Thanks. We’ll keep you updated';
	}
}

echo json_encode($data); 

?>